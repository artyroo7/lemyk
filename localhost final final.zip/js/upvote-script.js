/*==== Up/down voting widget  =====*/
Upvote.create('vote');
Upvote.create('vote2');